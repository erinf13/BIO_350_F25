DATA & FILE OVERVIEW

File List:

1. ce_perfrog.csv
2. Bd_Rv_Coinfection_Code.Rmd

Relationship between files:
Use file number 1 to run R code number 2.

DATA-SPECIFIC INFORMATION FOR: ce_perfrog.csv

Number of variables: 18

Number of rows: 54

Variable List:

1. ID: Frog identification number.
2. treatment: Experimental treatments or control group. Bd - animals were exposed to Bd only. Rv - animals were exposed to Rv only. Bd+Rv - animals were exposed to both Bd and Rv simultaneously; BdRv - animals were first exposed to Bd, and then to Rv in the second exposure; RvBd - animals were first exposed to Rv, and then to Bd in the second exposure; and ctr - control group.
3. censor: 1 when the frog died, and 0 when it survived until the end of the experiment.
4. death_day: Values reflect the number of days until death, (unit: days).
5. death_post_Bd: Values reflect the number of days until death after Bd exposure, (unit: days).
6. sex: F - Female, M - Male
7. fitness_d0: Values reflect the fitness (in grams) of each animal on day 0 of the experiment.
8. fitness_d10: Values reflect the fitness (in grams) of each animal on day 10 of the experiment.
9. fitness_d20: Values reflect the fitness (in grams) of each animal on day 20 of the experiment.
10. fitness_end: Values reflect the fitness (in grams) of each animal at the end of the experiment.
11. Bd_d0: Values reflect Bd load on day 0, measured in zoospore equivalents.
12. Bd_d10: Values reflect Bd load on day 10, measured in zoospore equivalents.
13. Bd_d20: Values reflect Bd load on day 20, measured in zoospore equivalents.
14. Bd_end: Values reflect Bd load at the end of the experiment or at the time of death, measured in zoospore equivalents.
15. Rv_d0: Values reflect Rv load on day 0, measured in MCP gene copies.
16. Rv_d10: Values reflect Rv load on day 10, measured in MCP gene copies.
17. Rv_d20: Values reflect Rv load on day 20, measured in MCP gene copies.
18. Rv_end: Values reflect Rv load at the end of the experiment or at the time of death, measured in MCP gene copies.



**Notes on "NA" Values**

All "NA" values in the dataset indicate "Not Applicable".



DATA-SPECIFIC INFORMATION FOR: Bd_Rv_Coinfection_Code.Rmd

Version of the packages used in the R code:
survminer_0.4.9
survival_3.5-8
multcomp_1.4-25
